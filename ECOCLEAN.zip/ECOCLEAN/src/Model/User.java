package Model;

public class User {
    
    private int cc;

    public User(int cc) {
        this.cc = cc;
    }

    public int getCc() {
        return cc;
    }

    public void setCc(int cc) {
        this.cc = cc;
    }
}

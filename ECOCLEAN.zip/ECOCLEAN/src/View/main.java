package View;

import Controller.Conexion;
import com.mysql.jdbc.Connection;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class main extends javax.swing.JDialog {

    Background bg;
    recycle rc;
    history hs;
    Connection con;
    Conexion conect;
    Statement st;
    PreparedStatement pst;
    ResultSet rs;
    public String name;
    public int cc;
    public int puntos;

    public main(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        bg = new Background();
        this.setContentPane(bg);
        initComponents();
        this.setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("/Pictures/leaf32.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jlabelBienvenida = new javax.swing.JLabel();
        btnubicacion = new javax.swing.JButton();
        btnconversion = new javax.swing.JButton();
        btnhistorial = new javax.swing.JButton();
        btnrecompensa = new javax.swing.JButton();
        btncuenta = new javax.swing.JButton();
        btnconfiguracion = new javax.swing.JButton();
        btnReciclar = new javax.swing.JButton();
        jlabelSaldo = new javax.swing.JLabel();
        btnCerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ECOCLEAN");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jlabelBienvenida.setFont(new java.awt.Font("Segoe UI Historic", 0, 24)); // NOI18N
        jlabelBienvenida.setForeground(new java.awt.Color(0, 0, 0));
        jlabelBienvenida.setText("Bienvenido");

        btnubicacion.setBackground(new java.awt.Color(51, 51, 51));
        btnubicacion.setForeground(new java.awt.Color(255, 255, 255));
        btnubicacion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/map.png"))); // NOI18N
        btnubicacion.setText("Ubicaciones");
        btnubicacion.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnubicacion.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnubicacion.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnubicacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnubicacionActionPerformed(evt);
            }
        });

        btnconversion.setBackground(new java.awt.Color(51, 51, 51));
        btnconversion.setForeground(new java.awt.Color(255, 255, 255));
        btnconversion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/energy.png"))); // NOI18N
        btnconversion.setText("Conversiones");
        btnconversion.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnconversion.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnconversion.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnconversion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnconversionActionPerformed(evt);
            }
        });

        btnhistorial.setBackground(new java.awt.Color(51, 51, 51));
        btnhistorial.setForeground(new java.awt.Color(255, 255, 255));
        btnhistorial.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/history.png"))); // NOI18N
        btnhistorial.setText("Historial");
        btnhistorial.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnhistorial.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnhistorial.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnhistorial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhistorialActionPerformed(evt);
            }
        });

        btnrecompensa.setBackground(new java.awt.Color(51, 51, 51));
        btnrecompensa.setForeground(new java.awt.Color(255, 255, 255));
        btnrecompensa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/reward.png"))); // NOI18N
        btnrecompensa.setText("Recompensas");
        btnrecompensa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnrecompensa.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnrecompensa.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnrecompensa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrecompensaActionPerformed(evt);
            }
        });

        btncuenta.setBackground(new java.awt.Color(51, 51, 51));
        btncuenta.setForeground(new java.awt.Color(255, 255, 255));
        btncuenta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/profile.png"))); // NOI18N
        btncuenta.setText("Cuenta");
        btncuenta.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btncuenta.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btncuenta.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btncuenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncuentaActionPerformed(evt);
            }
        });

        btnconfiguracion.setBackground(new java.awt.Color(51, 51, 51));
        btnconfiguracion.setForeground(new java.awt.Color(255, 255, 255));
        btnconfiguracion.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/settings.png"))); // NOI18N
        btnconfiguracion.setText("Configuracion");
        btnconfiguracion.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnconfiguracion.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnconfiguracion.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);

        btnReciclar.setBackground(new java.awt.Color(51, 51, 51));
        btnReciclar.setForeground(new java.awt.Color(255, 255, 255));
        btnReciclar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/recycle.png"))); // NOI18N
        btnReciclar.setText("Reciclar Ahora");
        btnReciclar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnReciclar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnReciclar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnReciclar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReciclarActionPerformed(evt);
            }
        });

        jlabelSaldo.setFont(new java.awt.Font("Segoe UI Historic", 0, 20)); // NOI18N
        jlabelSaldo.setForeground(new java.awt.Color(0, 0, 0));
        jlabelSaldo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/leaves.png"))); // NOI18N
        jlabelSaldo.setText("Actualmente tu saldo es:");
        jlabelSaldo.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);

        btnCerrar.setBackground(new java.awt.Color(51, 51, 51));
        btnCerrar.setForeground(new java.awt.Color(255, 255, 255));
        btnCerrar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/logout.png"))); // NOI18N
        btnCerrar.setText("Cerrar Sesion");
        btnCerrar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCerrar.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        btnCerrar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jlabelBienvenida)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnReciclar, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(btnhistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnconversion, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnrecompensa, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnubicacion, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btncuenta, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnconfiguracion, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jlabelSaldo))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlabelBienvenida)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnhistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnReciclar, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnrecompensa, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnconversion, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnCerrar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnubicacion, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                    .addComponent(btncuenta, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE)
                    .addComponent(btnconfiguracion, javax.swing.GroupLayout.DEFAULT_SIZE, 62, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 43, Short.MAX_VALUE)
                .addComponent(jlabelSaldo)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        login li = new login();
        this.dispose();
        li.setVisible(true);
    }//GEN-LAST:event_formWindowClosing

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        jlabelBienvenida.setText("Bienvenido, " + name + "!");
        jlabelSaldo.setText("Actualmente tu saldo es: " + String.valueOf(puntos) + " hojas");
    }//GEN-LAST:event_formWindowOpened

    private void btnubicacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnubicacionActionPerformed
        String dir = "";
        try {
            String query = "SELECT * FROM DIRECCION_PR";
            conect = new Conexion();
            con = conect.getConnection();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                dir = rs.getString("CIUDAD") + ", Calle " + rs.getString("CALLE") + " con Carrera " + rs.getString("CARRERA") + " #" + rs.getString("NUMERO") + " en el barrio " + rs.getString("BARRIO") + " " + "\n" + dir;
            }
            conect.Desconexion();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Se produjo un error al ingresar a la base de datos:\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
        JOptionPane.showMessageDialog(null, dir, "Lista de Ubicaciones", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnubicacionActionPerformed

    private void btnhistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhistorialActionPerformed
        String dir = "";
        try {
            String query = "SELECT ENCABEZADO_TRANSACCION.ID_ENCT, ENCABEZADO_TRANSACCION.ID_USUARIO, PUNTO_DE_RECICLAJE.NOMBRE, DETALLE_TRANSACCION.ID_MAQUINA, ENCABEZADO_TRANSACCION.FECHA_HORA, MATERIAL_RECICLABLE.NOMBRE, DETALLE_TRANSACCION.UNIDAD_ENTREGADA, DETALLE_TRANSACCION.PUNTOS_ADQUIRIDOS FROM USUARIO INNER JOIN ENCABEZADO_TRANSACCION ON USUARIO.ID_USUARIO = ENCABEZADO_TRANSACCION.ID_USUARIO INNER JOIN DETALLE_TRANSACCION ON ENCABEZADO_TRANSACCION.ID_ENCT = DETALLE_TRANSACCION.ID_DETT INNER JOIN PUNTO_DE_RECICLAJE ON ENCABEZADO_TRANSACCION.ID_PUNTO = PUNTO_DE_RECICLAJE.ID_PUNTO INNER JOIN MAQUINA_DE_RECICLAJE ON DETALLE_TRANSACCION.ID_MAQUINA = MAQUINA_DE_RECICLAJE.ID_MAQUINA INNER JOIN MATERIAL_RECICLABLE ON DETALLE_TRANSACCION.ID_MATERIAL = MATERIAL_RECICLABLE.ID_MATERIAL WHERE USUARIO.ID_USUARIO = '" + cc + "'";
            conect = new Conexion();
            con = conect.getConnection();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                dir = "ID TRANSACCION: " + rs.getInt("ENCABEZADO_TRANSACCION.ID_ENCT") + "\n FECHA Y HORA: " + rs.getString("ENCABEZADO_TRANSACCION.FECHA_HORA") + "\n ID USUARIO: " + rs.getInt("ENCABEZADO_TRANSACCION.ID_USUARIO") + "\n PUNTO DE RECICLAJE: " + rs.getString("PUNTO_DE_RECICLAJE.NOMBRE") + "\n PUNTOS ADQUIRIDOS: " + rs.getInt("DETALLE_TRANSACCION.PUNTOS_ADQUIRIDOS") + "\n UNIDAD_ENTREGADA: " + rs.getInt("DETALLE_TRANSACCION.UNIDAD_ENTREGADA") + "\n MATERIAL: " + rs.getString("MATERIAL_RECICLABLE.NOMBRE") + "\n -- \n" + dir;
            }
            conect.Desconexion();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Se produjo un error al ingresar a la base de datos:\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
        JOptionPane.showMessageDialog(null, dir, "Historial", JOptionPane.INFORMATION_MESSAGE);
        hs = new history(null, true);
        hs.setVisible(true);
    }//GEN-LAST:event_btnhistorialActionPerformed

    private void btnrecompensaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrecompensaActionPerformed
        String dir = "";
        try {
            String query = "SELECT * FROM RECOMPENSA";
            conect = new Conexion();
            con = conect.getConnection();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                dir = rs.getString("NOMBRE") + ", VALOR: " + rs.getInt("VALOR") + ", " + rs.getString("DESCRIPCION") + "\n" + dir;
            }
            conect.Desconexion();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Se produjo un error al ingresar a la base de datos:\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
        JOptionPane.showMessageDialog(null, dir, "Lista de Ubicaciones", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btnrecompensaActionPerformed

    private void btncuentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncuentaActionPerformed
        String dir = "";
        try {
            String query = "SELECT NOMBRES, APELLIDOS, EMAIL, PUNTOS, FECHA_REGISTRO FROM USUARIO WHERE ID_USUARIO = '" + cc + "'";
            conect = new Conexion();
            con = conect.getConnection();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            while (rs.next()) {
                dir = "NOMBRES: " + rs.getString("NOMBRES") + "\n APELLIDOS: " + rs.getString("APELLIDOS") + "\n EMAIL: " + rs.getString("EMAIL") + "\n HOJAS: " + rs.getInt("PUNTOS") + "\n FECHA DE REGISTRO: " + rs.getString("FECHA_REGISTRO");
            }
            conect.Desconexion();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Se produjo un error al ingresar a la base de datos:\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
        JOptionPane.showMessageDialog(null, dir, "Datos de la cuenta \n", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_btncuentaActionPerformed

    private void btnconversionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnconversionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnconversionActionPerformed

    private void btnReciclarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReciclarActionPerformed
        rc = new recycle(null, true);
        rc.setVisible(true);
    }//GEN-LAST:event_btnReciclarActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        login li = new login();
        this.dispose();
        li.setVisible(true);
    }//GEN-LAST:event_btnCerrarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                main dialog = new main(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrar;
    private javax.swing.JButton btnReciclar;
    private javax.swing.JButton btnconfiguracion;
    private javax.swing.JButton btnconversion;
    private javax.swing.JButton btncuenta;
    private javax.swing.JButton btnhistorial;
    private javax.swing.JButton btnrecompensa;
    private javax.swing.JButton btnubicacion;
    public javax.swing.JLabel jlabelBienvenida;
    private javax.swing.JLabel jlabelSaldo;
    // End of variables declaration//GEN-END:variables
    class Background extends JPanel {

        private Image pic;

        @Override
        public void paint(Graphics g) {
            pic = new ImageIcon(getClass().getResource("/Pictures/003.jpg")).getImage();
            g.drawImage(pic, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}

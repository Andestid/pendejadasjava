package View;

import Controller.Conexion;
import com.mysql.jdbc.Connection;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class signup extends javax.swing.JDialog {

    Background bg;
    Connection con;
    Conexion conect;
    Statement st;
    PreparedStatement pst;
    ResultSet rs;
    Calendar cld;

    public signup(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        bg = new Background();
        this.setContentPane(bg);
        initComponents();
        this.setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("/Pictures/leaf32.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        jlabelcc = new javax.swing.JLabel();
        txtCC = new javax.swing.JTextField();
        jlabelpass = new javax.swing.JLabel();
        txtPass = new javax.swing.JPasswordField();
        jlabelNombres = new javax.swing.JLabel();
        jlabelApellidos = new javax.swing.JLabel();
        txtNombres = new javax.swing.JTextField();
        txtApellidos = new javax.swing.JTextField();
        jlabelEmail = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        btnRegistrarme = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ECOCLEAN / REGISTRO");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        Titulo.setBackground(new java.awt.Color(255, 255, 255));
        Titulo.setFont(new java.awt.Font("Rockwell Extra Bold", 2, 36)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 0, 0));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Titulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/leaf64.png"))); // NOI18N
        Titulo.setText("ECOCLEAN");
        Titulo.setToolTipText("");

        jlabelcc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelcc.setText("Documento (CC):");

        jlabelpass.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelpass.setText("Contraseña:");

        jlabelNombres.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelNombres.setText("Nombres:");

        jlabelApellidos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelApellidos.setText("Apellidos:");

        jlabelEmail.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelEmail.setText("E-Mail:");

        btnRegistrarme.setText("Registrarme");
        btnRegistrarme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarmeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jlabelApellidos)
                                        .addComponent(jlabelNombres)
                                        .addComponent(jlabelEmail))
                                    .addGap(64, 64, 64))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jlabelcc)
                                    .addGap(18, 18, 18)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(txtApellidos)
                                .addComponent(txtNombres)
                                .addComponent(txtCC)
                                .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                            .addComponent(jlabelpass)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btnRegistrarme)
                                .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(90, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(Titulo)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabelcc)
                    .addComponent(txtCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNombres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlabelNombres))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellidos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlabelApellidos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlabelEmail))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jlabelpass))
                .addGap(18, 18, 18)
                .addComponent(btnRegistrarme)
                .addContainerGap(57, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarmeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarmeActionPerformed
        String pass = new String(txtPass.getPassword());
        cld = Calendar.getInstance();
        int year = cld.get(Calendar.YEAR);
        int month = cld.get(Calendar.MONTH);
        int day = cld.get(Calendar.DAY_OF_MONTH);
        int hour = cld.get(Calendar.HOUR_OF_DAY);
        int min = cld.get(Calendar.MINUTE);
        int sec = cld.get(Calendar.SECOND);
        String fecha = String.valueOf(year) + "-" + String.valueOf(month) + "-" + String.valueOf(day) + "-" + String.valueOf(hour) + "-" + String.valueOf(min) + "-" + String.valueOf(sec);
        try {
            String query = "INSERT INTO USUARIO (ID_USUARIO, NOMBRES, APELLIDOS, EMAIL, CONTRASENA, PUNTOS, FECHA_REGISTRO) VALUES (?,?,?,?,?,?,?)";
            conect = new Conexion();
            con = conect.getConnection();
            pst = con.prepareStatement(query);
            pst.setString(1, txtCC.getText());
            pst.setString(2, txtNombres.getText());
            pst.setString(3, txtApellidos.getText());
            pst.setString(4, txtEmail.getText());
            pst.setString(5, pass);
            pst.setInt(6, 0);
            pst.setString(7, fecha);
            int ans = pst.executeUpdate();
            if (ans > 0) {
                JOptionPane.showMessageDialog(this, "¡Registro completado correctamente!", "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
                login li = new login();
                this.dispose();
                li.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "¡No se ha podido registrar los datos ingresados!", "Error de registro", JOptionPane.ERROR_MESSAGE);
            }
            conect.Desconexion();
        } catch (SQLException | HeadlessException ex) {
            JOptionPane.showMessageDialog(this, "Se produjo un error al ingresar a la base de datos:\n" + ex, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnRegistrarmeActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        login li = new login();
        this.dispose();
        li.setVisible(true);
    }//GEN-LAST:event_formWindowClosing

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(signup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                signup dialog = new signup(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton btnRegistrarme;
    private javax.swing.JLabel jlabelApellidos;
    private javax.swing.JLabel jlabelEmail;
    private javax.swing.JLabel jlabelNombres;
    private javax.swing.JLabel jlabelcc;
    private javax.swing.JLabel jlabelpass;
    private javax.swing.JTextField txtApellidos;
    private javax.swing.JTextField txtCC;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtNombres;
    private javax.swing.JPasswordField txtPass;
    // End of variables declaration//GEN-END:variables
    class Background extends JPanel {

        private Image pic;

        @Override
        public void paint(Graphics g) {
            pic = new ImageIcon(getClass().getResource("/Pictures/002.jpg")).getImage();
            g.drawImage(pic, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}

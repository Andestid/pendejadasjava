package View;

import java.awt.Graphics;
import java.awt.Image;
import java.util.Calendar;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class recycle extends javax.swing.JDialog {

    Background bg;
    Calendar cld;

    public recycle(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        bg = new Background();
        this.setContentPane(bg);
        initComponents();
        this.setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("/Pictures/leaf32.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelmaterial = new javax.swing.JLabel();
        jcmbMaterial = new javax.swing.JComboBox<>();
        labelcantidad = new javax.swing.JLabel();
        jspinnerCantidad = new javax.swing.JSpinner();
        jlabelUnidad = new javax.swing.JLabel();
        jlabelfecha = new javax.swing.JLabel();
        txtFecha = new javax.swing.JTextField();
        btnAceptar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("ECOCLEAN / RECICLAR");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        labelmaterial.setText("Material");

        jcmbMaterial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccionar", "Plastico", "Vidrio", "Aluminio", "Aceite", "Quimico" }));
        jcmbMaterial.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jcmbMaterialItemStateChanged(evt);
            }
        });

        labelcantidad.setText("Cantidad");

        jspinnerCantidad.setModel(new javax.swing.SpinnerNumberModel(0, 0, 100, 1));

        jlabelUnidad.setText("Unidad: N/A");

        jlabelfecha.setText("Fecha");

        txtFecha.setEditable(false);
        txtFecha.setEnabled(false);

        btnAceptar.setText("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnAceptar)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelmaterial)
                            .addComponent(jlabelfecha))
                        .addGap(23, 23, 23)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jcmbMaterial, 0, 128, Short.MAX_VALUE)
                            .addComponent(txtFecha))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlabelUnidad)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(labelcantidad)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jspinnerCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelmaterial)
                    .addComponent(jcmbMaterial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelcantidad)
                    .addComponent(jspinnerCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabelUnidad)
                    .addComponent(jlabelfecha)
                    .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnAceptar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed

    }//GEN-LAST:event_btnAceptarActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        cld = Calendar.getInstance();
        int year = cld.get(Calendar.YEAR);
        int month = cld.get(Calendar.MONTH);
        int day = cld.get(Calendar.DAY_OF_MONTH);
        int hour = cld.get(Calendar.HOUR_OF_DAY);
        int min = cld.get(Calendar.MINUTE);
        int sec = cld.get(Calendar.SECOND);
        String fecha = String.valueOf(year) + "-" + String.valueOf(month) + "-" + String.valueOf(day) + "-" + String.valueOf(hour) + "-" + String.valueOf(min) + "-" + String.valueOf(sec);
        txtFecha.setText(fecha);
    }//GEN-LAST:event_formWindowOpened

    private void jcmbMaterialItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jcmbMaterialItemStateChanged
        String unidad = (String.valueOf(jcmbMaterial.getSelectedItem()));
        switch (unidad) {
            case "Plastico" -> jlabelUnidad.setText("Unidad: Kg");
            case "Vidrio" -> jlabelUnidad.setText("Unidad: Kg");
            case "Aluminio" -> jlabelUnidad.setText("Unidad: Kg");
            case "Aceite" -> jlabelUnidad.setText("Unidad: ml");
            case "Quimico" -> jlabelUnidad.setText("Unidad: ml");
            case "Seleccionar" -> jlabelUnidad.setText("Unidad: N/A");
            default -> {
            }
        }
    }//GEN-LAST:event_jcmbMaterialItemStateChanged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(recycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(recycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(recycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(recycle.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                recycle dialog = new recycle(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAceptar;
    private javax.swing.JComboBox<String> jcmbMaterial;
    private javax.swing.JLabel jlabelUnidad;
    private javax.swing.JLabel jlabelfecha;
    private javax.swing.JSpinner jspinnerCantidad;
    private javax.swing.JLabel labelcantidad;
    private javax.swing.JLabel labelmaterial;
    private javax.swing.JTextField txtFecha;
    // End of variables declaration//GEN-END:variables
    class Background extends JPanel {

        private Image pic;

        @Override
        public void paint(Graphics g) {
            pic = new ImageIcon(getClass().getResource("/Pictures/003.jpg")).getImage();
            g.drawImage(pic, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}

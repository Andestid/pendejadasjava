package View;

import Controller.Conexion;
import Model.User;
import com.mysql.jdbc.Connection;
import java.awt.Graphics;
import java.awt.HeadlessException;
import java.awt.Image;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class login extends javax.swing.JFrame {

    Background bg;
    signup su;
    main ma;
    User us;
    Connection con;
    Conexion conect;
    Statement st;
    PreparedStatement pst;
    ResultSet rs;

    public login() {
        bg = new Background();
        this.setContentPane(bg);
        initComponents();
        this.setLocationRelativeTo(null);
        setIconImage(new ImageIcon(getClass().getResource("/Pictures/leaf32.png")).getImage());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Titulo = new javax.swing.JLabel();
        jlabelcc = new javax.swing.JLabel();
        jlabelpass = new javax.swing.JLabel();
        txtCC = new javax.swing.JTextField();
        txtPass = new javax.swing.JPasswordField();
        btnLogin = new javax.swing.JButton();
        jlabelSignup = new javax.swing.JLabel();
        btnSignup = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ECOCLEAN / INICIO DE SESION");

        Titulo.setBackground(new java.awt.Color(255, 255, 255));
        Titulo.setFont(new java.awt.Font("Rockwell Extra Bold", 2, 36)); // NOI18N
        Titulo.setForeground(new java.awt.Color(0, 0, 0));
        Titulo.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        Titulo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Pictures/leaf64.png"))); // NOI18N
        Titulo.setText("ECOCLEAN");
        Titulo.setToolTipText("");

        jlabelcc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelcc.setText("Documento (CC):");

        jlabelpass.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelpass.setText("Contraseña:");

        btnLogin.setText("Ingresar");
        btnLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLoginActionPerformed(evt);
            }
        });

        jlabelSignup.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jlabelSignup.setText("No tengo una cuenta");

        btnSignup.setText("Registrarme");
        btnSignup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSignupActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Titulo, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jlabelcc)
                                    .addComponent(jlabelpass))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCC, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnLogin)
                                    .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jlabelSignup)
                                .addGap(18, 18, 18)
                                .addComponent(btnSignup)))))
                .addContainerGap(94, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(Titulo)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabelcc)
                    .addComponent(txtCC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabelpass)
                    .addComponent(txtPass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnLogin)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlabelSignup)
                    .addComponent(btnSignup))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void btnLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoginActionPerformed
        int cc = Integer.parseInt(txtCC.getText());
        String pass = new String(txtPass.getPassword());
        us = new User(cc);
        try {
            String query = "SELECT ID_USUARIO, NOMBRES, CONTRASENA, PUNTOS FROM USUARIO WHERE ID_USUARIO = '" + us.getCc() + "'";
            conect = new Conexion();
            con = conect.getConnection();
            pst = con.prepareStatement(query);
            rs = pst.executeQuery();
            if (rs.next()) {
                if (pass.equals(rs.getString("CONTRASENA"))) {
                    ma = new main(this, true);
                    this.dispose();
                    ma.cc = us.getCc();
                    ma.name = rs.getString("NOMBRES");
                    ma.puntos = rs.getInt("PUNTOS");
                    ma.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(null, "¡Contraseña incorrecta!", "Error de inicio", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "¡No existe un usuario registrado con esta cedula!", "Error de consulta", JOptionPane.ERROR_MESSAGE);
            }
            conect.Desconexion();
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(null, "Se produjo un error al ingresar a la base de datos:\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnLoginActionPerformed

    private void btnSignupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSignupActionPerformed
        su = new signup(this, true);
        this.dispose();
        su.setVisible(true);
    }//GEN-LAST:event_btnSignupActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Titulo;
    private javax.swing.JButton btnLogin;
    private javax.swing.JButton btnSignup;
    private javax.swing.JLabel jlabelSignup;
    private javax.swing.JLabel jlabelcc;
    private javax.swing.JLabel jlabelpass;
    private javax.swing.JTextField txtCC;
    private javax.swing.JPasswordField txtPass;
    // End of variables declaration//GEN-END:variables
    class Background extends JPanel {

        private Image pic;

        @Override
        public void paint(Graphics g) {
            pic = new ImageIcon(getClass().getResource("/Pictures/002.jpg")).getImage();
            g.drawImage(pic, 0, 0, getWidth(), getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}

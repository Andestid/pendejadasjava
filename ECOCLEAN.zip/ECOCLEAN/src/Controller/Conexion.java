package Controller;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Conexion {
    private final String driver = "com.mysql.jdbc.Driver";
    private final String user = "root";
    private final String pass = "123";
    private final String url = "jdbc:mysql://localhost:3306/ecocleandb?characterEncoding=latin1&useConfigs=maxPerformance";
    Connection con;
    Statement st;

    public Conexion() {
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            st = con.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer conexión con la base de datos\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public Connection getConnection() {
        return con;
    }

    public void Desconexion() {
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

/* Clase multilista que contendra todas las operaciones que se realizan sobre la 
 * multilista
* 
 */

/**
 * @author Sergio Jiménez M
 *  sjimenez@unisimonbolivar.edu.co
 */
public class multilista {
    public nodosala L; // apuntador al inicio de la lista

    public multilista() {
        L = null;
    }//end constructor
    
//---------- retorna la direccion del  ultimo elemento de la lista padre (sala)    
    public nodosala ultimosala()
    {
        nodosala p=L;
        while(p!=null)
        {
            if(p.sig==null) return p;
            p=p.sig;
        }    
        
        return null;
    }//end ultimo sala        
    
//---------- retorna la direccion del  ultimo elemento de la lista hija (equipo)    
    public nodoequipo ultimoequipo(nodoequipo lista)
    {
         nodoequipo p=lista;
        while(p!=null)
        {
            if(p.sig==null) return p;
            p=p.sig;
        }    
        
        return null;
    }//end ultimoequipo     
//----------------- inserta una sala al final de la lista---------------------------    
   public void insertasala(nodosala dato)
   {
       nodosala u=ultimosala(); //busca el ultimo
       nodosala x=new nodosala(dato);
       if(u!=null) // si hay lista lo enlaza
       {
           u.sig=x;
           x.ant=u;
       } 
       else // si no hay lista la crea L=x
           L=x; 
   }//end insertar        

//---------- busca la direccion de una sala en la lista padre (sala)    
    public nodosala buscarsala(nodosala dato)
    {
        nodosala p=L;
        while(p!=null)
        {
            if(p.id==dato.id) return p;
            p=p.sig;
        }    
        
        return null;
    }//end ultimo sala        
//------------------- inserta un computador al final de la lista de una sala dada---------    
   public void insertapc(nodosala sala, nodoequipo pc)
   {
       nodosala p=buscarsala(sala);
       if(p!=null)
       {
           nodoequipo u=ultimoequipo(p.pchijo); // busca la direccion del la lista del nodo hijo 
           nodoequipo x=new nodoequipo(pc); //crea el nodo 
           if(u!=null) // si hay lista
           {
               u.sig=x; // lo enlaza con el ultimo 
           } 
            else
               p.pchijo=x; // lo pone al prinicpio de la lista 
       }//end if
        else
           javax.swing.JOptionPane.showMessageDialog(null, "No existe la sala  "+sala.id);
   }//end insertar pc        
   
//-------------- Imprime todos las salas con sus equipo---------------------------------
   public void imprimir()
   {
       nodosala p=L;
       nodoequipo q;
       
       while(p!=null)
       {
           System.out.println("Sala "+p.id+" Nombre sala "+p.nombre+" Equipos:");
           System.out.println("==================================================");
           q=p.pchijo;
           while(q!=null)
           {
               System.out.println("Ip "+q.ip+" Marca "+q.marca);
               q=q.sig;
           }//end while q    
           System.out.println("==================================================");
           p=p.sig;
       }//end while p   
       
   }//end imprimir        
    
}//end class

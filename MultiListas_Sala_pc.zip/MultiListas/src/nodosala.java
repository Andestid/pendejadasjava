/*
 *  En este nodo se define la estructura del nodo padre (Sala de informatica)
 *  Que contiene los datos Id y nombre de la sala
 */
/**
 *
 * @author Sergio Jiménez M
 *  sjimenez@unisimonbolivar.edu.co
 */
public class nodosala {
    public nodosala ant; // apuntador alnodo anterior
    public int id;
    public String nombre;
    public nodoequipo pchijo; // apuntador al nodo hijo lista de pc de la sala
    public nodosala sig; // apuntador al nodo sig
    
    public nodosala()
    {
        pchijo=null;
        ant=null;
        sig=null;
    }         
    
    
    public nodosala( nodosala dato)
    {
        id=dato.id;
        nombre=dato.nombre;
        pchijo=null;
        ant=null;
        sig=null;
    }         
}

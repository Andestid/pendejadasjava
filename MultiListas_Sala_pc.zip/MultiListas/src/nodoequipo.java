/*
 *  en esta clase se define el nodo hijo  nodoequipo que contiene los datos d elos equipos (pc)
 * Que contiene cada sala de computadores
 */

/**
 @author Sergio Jiménez M
 *  sjimenez@unisimonbolivar.edu.co
 */
public class nodoequipo {
    public String ip;
    public String marca;
    public nodoequipo sig;
    
    public nodoequipo()
    {
        sig=null;
    }   
    
    public nodoequipo(nodoequipo dato)
    {
        ip=dato.ip;
        marca=dato.marca;
        sig=null;
    }        
}

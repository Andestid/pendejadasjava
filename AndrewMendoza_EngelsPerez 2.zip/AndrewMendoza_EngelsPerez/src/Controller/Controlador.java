package Controller;

import Model.Arbol;
import javax.swing.JOptionPane;

public class Controlador {

    public Arbol Raiz;

    public Controlador() {
        Raiz = null;
    }

    public void Inorden(Arbol R) {
        if (R != null) {
            Inorden(R.LI);
            System.out.println("Nombre: " + R.nombre);
            System.out.println("Curso: " + R.asignatura);
            System.out.println("Definitiva: " + R.definitiva);
            System.out.println("Edad: " + R.edad);
            Inorden(R.LD);
        }
    }

    public void Preorden(Arbol R) {
        if (R != null) {
            System.out.println("Nombre: " + R.nombre);
            System.out.println("Curso: " + R.asignatura);
            System.out.println("Definitiva: " + R.definitiva);
            System.out.println("Edad: " + R.edad);
            Preorden(R.LI);
            Preorden(R.LD);
        }
    }

    public void Insertar(Arbol R, String nombre, String sexo, int edad, double p1, double p2, double examen, double definitiva, String curso) {
        if (Raiz == null) {
            Raiz = new Arbol(nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            return;
        }
        if (nombre.compareTo(R.nombre) < 0) {
            if (R.LI == null) {
                R.LI = new Arbol(nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            } else {
                Insertar(R.LI, nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            }
        } else if (nombre.compareTo(R.nombre) > 0) {
            if (R.LD == null) {
                R.LD = new Arbol(nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            } else {
                Insertar(R.LD, nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            }
        } else {
            System.out.println("ERROR");
        }
    }

    public void definitiva(Arbol R, String nombre, String sexo, int edad, double p1, double p2, double examen, double definitiva, String curso) {
        double v = ((R.p1 * 30) + (R.p2 * 30) + (R.examen * 40)) / 3;
        JOptionPane.showMessageDialog(null, "La definitiva es: " + v);
    }
}

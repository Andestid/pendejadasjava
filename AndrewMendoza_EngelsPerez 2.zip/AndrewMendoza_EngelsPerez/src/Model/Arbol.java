
package Model;


public class Arbol {
    public Arbol LI;
   public String nombre;
   public String sexo;
   public int edad;
   public double p1;
   public double p2;
   public double examen;
   public double definitiva;
   public String asignatura;
    public Arbol LD;

    public Arbol() {
        LI = null;
        LD = null;

    }

    public Arbol(String nombre,String sexo,int edad, double p1,double p2,double examen,double definitiva,String curso) {
       this.nombre=nombre;
       this.sexo=sexo;
       this.edad=edad;
       this.p1=p1;
       this.p2=p2;
       this.examen=examen;
       asignatura=curso;
       this.definitiva=definitiva;
        LI = null;
        LD = null;

    }
}

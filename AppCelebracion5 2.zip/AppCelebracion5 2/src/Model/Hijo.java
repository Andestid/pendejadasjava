package Model;

import javax.swing.JOptionPane;

public class Hijo {

    //Atributos
    private String nombre;
    private String id;
    private String idp;
    private String fecha;
    private String sexo;

    public Hijo(String nombre, String id, String idp, String fecha, String sexo) {
        this.nombre = nombre;
        this.id = id;
        this.idp = idp;
        this.fecha = fecha;
        this.sexo = sexo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getId() {
        return id;
    }

    public String getIdp() {
        return idp;
    }

    public String getFecha() {
        return fecha;
    }

    public String getSexo() {
        return sexo;
    }

    public void mostrar() {
        String salida = "Nombre " + getNombre()
                + "\nIdentificacion: " + getId()
                + "\nIdentificacion del padre: " + getIdp()
                + "\nFecha: " + getFecha()
                + "\nSexo: " + getSexo();
        JOptionPane.showMessageDialog(null, salida, "Datos del hijo(a)", JOptionPane.INFORMATION_MESSAGE);
    }

}

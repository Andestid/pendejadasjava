package appcelebracion;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import appcelebracion.Conexion;
import java.sql.SQLException;
import javafx.scene.control.Label;
import javax.swing.JOptionPane;

public class FXMLDocumentController implements Initializable {

    private Conexion cx;
    int tvh = 0;
    int tvm = 0;
    int opc = 0;
    int gradop, grado2, grado3, grado4, grado5, grado6, grado7, grado8, grado9, grado10, grado11;
    int ej = 0;
    int ei = 0;
    boolean sw;

    @FXML
    private ComboBox<Integer> grado;
    private ObservableList lista_grados;

    @FXML
    private TextField cedula_madre;
    @FXML
    private Label lbconsulta;

    @FXML
    private TextField nombre_madre;

    @FXML
    private TextField cedulam_busqueda;

    @FXML
    private TextField identificacionh_busqueda;
    @FXML
    private Button btejecutar;

    @FXML
    private TextField profesion;

    @FXML
    private TextField direccion;
    @FXML
    private Button boton_consultam;

    @FXML
    private Button boton_consultah;

    @FXML
    private TextArea mensaje_madre;

    @FXML
    private Button boton_registrarmadre;

    @FXML
    private TextArea taconsulta;
    @FXML
    private Button boton_listarmadre;
    @FXML
    private TextArea consultas_madre;

    @FXML
    private TextArea consultas_hijo;

    @FXML
    private TextField identificacion_hijo;

    @FXML
    private TextField nombre_hijo;

    @FXML
    private Button boton_registrar_hijo;

    @FXML
    private Button boton_listarh;

    @FXML
    private TextArea mensaje_hijo;

    @FXML
    private TextField tfcedulab;

    @FXML
    private TextField cedula_madre1;

    //Metodos para llamar
    @FXML
    private void registroh() throws SQLException {
        nombre_hijo.requestFocus();

        boolean result = true;
        int identificacionh_registrada = 0;
        int identificacionm_registrada = 0;

        java.sql.ResultSet rs = cx.buscarmadres(Integer.parseInt(cedula_madre1.getText()));
        if (rs.next()) {
            java.sql.ResultSet rx = cx.buscarhijos(Integer.parseInt(identificacion_hijo.getText()));
            if (!rx.next()) {

                clear_hijo();
            } else {
                JOptionPane.showMessageDialog(null, "Hijo ya existente...");
                clear_hijo();
                consultas_madre.setText("");
                consultas_hijo.setText("");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Madre no existente...");
            consultas_madre.setText("");
            consultas_hijo.setText("");
            clear_hijo();
        }
    }

    @FXML
    public void listarh() { //Metodo para listar madres

        taconsulta.setText(cx.mostrahijos());
        clear_hijo();
        consultas_madre.setText("");
    }

    public void clear_hijo() {

        identificacion_hijo.clear();
        nombre_hijo.clear();
        cedula_madre1.clear();
        lista_grados.clear();

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cx = new Conexion();

    }
}

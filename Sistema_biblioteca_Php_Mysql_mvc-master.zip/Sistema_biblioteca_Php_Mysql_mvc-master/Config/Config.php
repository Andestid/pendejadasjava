<?php
    const BASE_URL = "http://localhost/biblioteca_mvc/";
    const HOST = "localhost";
    const BD = "biblioteca_mvc";
    const DB_USER = "root";
    const PASS = "";
    const CHARSET = "charset=utf8";
?>
package Controller;

import Modelo.Nodo;

public class Operaciones {

    public Nodo Raiz;

    public Operaciones() {
        Raiz = null;
    }

    public void Insertar(Nodo R, Nodo dato) {
        if (Raiz == null) {
            Raiz = new Nodo(dato);
            return;
        }
        if (dato.placa.compareToIgnoreCase(R.placa) < 0) {
            if (R.LI == null) {
                R.LI = new Nodo(dato);
            } else {
                Insertar(R.LI, dato);
            }
        } else if (dato.placa.compareToIgnoreCase(R.placa) > 0) {
            if (R.LD == null) {
                R.LD = new Nodo(dato);
            } else {
                Insertar(R.LD, dato);
            }
        } else {
            System.out.println("Error datos duplicado");
        }
    }

    public void ImprimirNodo(Nodo R) {
        System.out.println(
                "    ===========Registro=========="
                + "\n Placa: " + R.placa
                + "\n Modelo: " + R.modelo
                + "\n Kilometraje: " + R.kilometraje
                + "\n Propietario: " + R.propietario
                + "\n Valor: " + R.valor
                + "\n Estado: " + R.estado
                + "\n ============================");
    }
//-- Inorden (IRD)
    public String E;

    public void Inorden(Nodo R) {
        if (R != null) {
            Inorden(R.LI);
            ImprimirNodo(R);
            Inorden(R.LD);
        }
    }

    private Nodo menor = null;

    public void MenorK(Nodo R) {
        if (R != null) {
            MenorK(R.LI);
            if (R.kilometraje < menor.kilometraje) {
                menor = R;
            }
            MenorK(R.LD);

        }
    }

    public void menorkilometro(Nodo R) {
        menor = Raiz;
        MenorK(R);
        System.out.println("===Menor Kilometraje===");
        ImprimirNodo(menor);
    }

    public void punto3_1(Nodo R) {
        if (R != null) {
            punto3_1(R.LI);
            if (((R.kilometraje < 30000) && (R.valor < 25000000)) && (R.estado.equals("En venta"))) {
                ImprimirNodo(R);
            }
            punto3_1(R.LD);

        }
    }

}

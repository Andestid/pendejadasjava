package Modelo;

public class Nodo {

    public Nodo LI;
    public String placa;
    public int modelo;
    public int kilometraje;
    public String propietario;
    public String estado;
    public double valor;
    public Nodo LD;

    public Nodo() {
        LI = null;
        LD = null;
    }

    public Nodo(Nodo vehiculo) {
        placa = vehiculo.placa;
        modelo = vehiculo.modelo;
        kilometraje = vehiculo.kilometraje;
        propietario = vehiculo.propietario;
        valor = vehiculo.valor;
        estado = vehiculo.estado;
        LI = null;
        LD = null;
    }
}

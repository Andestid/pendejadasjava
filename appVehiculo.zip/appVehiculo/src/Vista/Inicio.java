package Vista;

import Modelo.Nodo;
import Controller.Operaciones;
import javax.swing.JOptionPane;

public class Inicio extends javax.swing.JFrame {

    private Nodo dato;
    private Operaciones arbvehiculo;

    public Inicio() {
        initComponents();
        dato = new Nodo();
        arbvehiculo = new Operaciones();
    }

    public void Capturar() {
        dato.placa = txtplaca.getText();
        dato.propietario = txtprop.getText();
        dato.estado = cmbestado.getSelectedItem().toString();
        dato.valor = Double.parseDouble(txtvalor.getText());
        dato.kilometraje = Integer.parseInt(txtkilo.getText());
        dato.modelo = Integer.parseInt(txtmodelo.getText());

    }

    public void Nuevo() {
        txtkilo.setText("");
        txtmodelo.setText("");
        txtplaca.setText("");
        txtprop.setText("");
        txtvalor.setText("");
        cmbestado.setSelectedItem(0);
        txtplaca.requestFocus();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtplaca = new javax.swing.JTextField();
        txtmodelo = new javax.swing.JTextField();
        txtkilo = new javax.swing.JTextField();
        txtprop = new javax.swing.JTextField();
        cmbestado = new javax.swing.JComboBox<>();
        txtvalor = new javax.swing.JTextField();
        btninsertar = new javax.swing.JButton();
        btnimprimir = new javax.swing.JButton();
        btmkilomenor = new javax.swing.JButton();
        btnvehiventa = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtplaca.setBorder(javax.swing.BorderFactory.createTitledBorder("Placa"));
        txtplaca.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtplacaActionPerformed(evt);
            }
        });

        txtmodelo.setBorder(javax.swing.BorderFactory.createTitledBorder("Modelo"));

        txtkilo.setBorder(javax.swing.BorderFactory.createTitledBorder("Kilometraje"));
        txtkilo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtkiloActionPerformed(evt);
            }
        });

        txtprop.setBorder(javax.swing.BorderFactory.createTitledBorder("Propietario"));

        cmbestado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "---Seleccione---", "Vendido", "Apartado", "En venta" }));
        cmbestado.setBorder(javax.swing.BorderFactory.createTitledBorder("Estado"));
        cmbestado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbestadoActionPerformed(evt);
            }
        });

        txtvalor.setBorder(javax.swing.BorderFactory.createTitledBorder("Valor"));

        btninsertar.setText("Insertar");
        btninsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninsertarActionPerformed(evt);
            }
        });

        btnimprimir.setText("Imprimir");
        btnimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimprimirActionPerformed(evt);
            }
        });

        btmkilomenor.setText("Kilometraje menor");
        btmkilomenor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmkilomenorActionPerformed(evt);
            }
        });

        btnvehiventa.setText("Vehiculos en venta");
        btnvehiventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnvehiventaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtmodelo, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(txtkilo)
                    .addComponent(txtprop)
                    .addComponent(txtvalor)
                    .addComponent(cmbestado, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtplaca))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(16, 16, 16)
                        .addComponent(btninsertar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnimprimir)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btmkilomenor))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btnvehiventa)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtplaca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtmodelo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtkilo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtprop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtvalor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cmbestado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btninsertar)
                            .addComponent(btnimprimir)
                            .addComponent(btmkilomenor))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnvehiventa)))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtplacaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtplacaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtplacaActionPerformed

    private void txtkiloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtkiloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtkiloActionPerformed

    private void cmbestadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbestadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbestadoActionPerformed

    private void btmkilomenorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmkilomenorActionPerformed
        // TODO add your handling code here:
        arbvehiculo.menorkilometro(arbvehiculo.Raiz);
    }//GEN-LAST:event_btmkilomenorActionPerformed

    private void btninsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninsertarActionPerformed
        // TODO add your handling code here:
        Capturar();
        arbvehiculo.Insertar(arbvehiculo.Raiz, dato);
        Nuevo();
        JOptionPane.showMessageDialog(null, "---Dato insertado---");
    }//GEN-LAST:event_btninsertarActionPerformed

    private void btnimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimprimirActionPerformed
        // TODO add your handling code here:
        arbvehiculo.Inorden(arbvehiculo.Raiz);
    }//GEN-LAST:event_btnimprimirActionPerformed

    private void btnvehiventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnvehiventaActionPerformed
        // TODO add your handling code here:
        arbvehiculo.punto3_1(arbvehiculo.Raiz);
                
    }//GEN-LAST:event_btnvehiventaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmkilomenor;
    private javax.swing.JButton btnimprimir;
    private javax.swing.JButton btninsertar;
    private javax.swing.JButton btnvehiventa;
    private javax.swing.JComboBox<String> cmbestado;
    private javax.swing.JTextField txtkilo;
    private javax.swing.JTextField txtmodelo;
    private javax.swing.JTextField txtplaca;
    private javax.swing.JTextField txtprop;
    private javax.swing.JTextField txtvalor;
    // End of variables declaration//GEN-END:variables
}

package Model;

import appcelebracion.Persona;
import javax.swing.JOptionPane;

public class Madre extends Persona {
//Atributos

    private String profesion;
    private String direccion;


    public Madre(String ident, String nombre,String profesion, String direccion) {
        super(ident, nombre);
        this.profesion = profesion;
        this.direccion = direccion;

    }

    public String getProfesion() {
        return profesion;
    }

    public String getDireccion() {
        return direccion;
    }


    @Override
    public void mostrar() {
        String salida = "Identificación: " + getIdent()
                + "\nNombre: " + getNombre()
                + "\nProfesión: " + profesion
                + "\nDirección: " + direccion;
        JOptionPane.showMessageDialog(null, salida, "Datos Madre", JOptionPane.INFORMATION_MESSAGE);
    }

}

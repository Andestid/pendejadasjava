package Controller;
import Model.Hijo;
import Model.Madre;
import Model.Persona;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.sql.SQLException;
import javafx.scene.control.Label;
import javax.swing.JOptionPane;

public class FXMLDocumentController implements Initializable {

    private Conexion cx;
    Madre vm[] = new Madre[10];
    Hijo vh[] = new Hijo[10];

    int tvh = 0;
    int tvm = 0;
    int opc = 0;
    int gradop, grado2, grado3, grado4, grado5, grado6, grado7, grado8, grado9, grado10, grado11;
    int ej = 0;
    int ei = 0;
    boolean sw;

    @FXML
    private ComboBox<Integer> grado;
    private ObservableList lista_grados;

    @FXML
    private TextField cedula_madre;
    @FXML
    private Label lbconsulta;

    @FXML
    private TextField nombre_madre;

    @FXML
    private TextField cedulam_busqueda;

    @FXML
    private TextField identificacionh_busqueda;
    @FXML
    private Button btejecutar;

    @FXML
    private TextField profesion;

    @FXML
    private TextField direccion;
    @FXML
    private Button boton_consultam;

    @FXML
    private Button boton_consultah;

    @FXML
    private TextArea mensaje_madre;

    @FXML
    private Button boton_registrarmadre;

    @FXML
    private TextArea taconsulta;
    @FXML
    private Button boton_listarmadre;
    @FXML
    private TextArea consultas_madre;

    @FXML
    private TextArea consultas_hijo;

    @FXML
    private TextField identificacion_hijo;

    @FXML
    private TextField nombre_hijo;

    @FXML
    private Button boton_registrar_hijo;

    @FXML
    private Button boton_listarh;

    @FXML
    private TextArea mensaje_hijo;

    @FXML
    private TextField tfcedulab;

    @FXML
    private TextField cedula_madre1;

    //Metodos para llamar
    @FXML
    private void registrom() throws SQLException {

//Este metodo sirve para registrar las madres
        java.sql.ResultSet rs = cx.buscarmadres(Integer.parseInt(cedula_madre.getText()));
        if (!rs.next()) {
            cx.registrarMadre(nombre_madre.getText(), Integer.parseInt(cedula_madre.getText()), profesion.getText(), direccion.getText());
            clear_madre();
            consultas_madre.setText("");
            consultas_hijo.setText("");
        } else {
             clear_madre();
            JOptionPane.showMessageDialog(null, "Madre ya existente...");
            consultas_madre.setText("");
            consultas_hijo.setText("");
           
        }
    }

    @FXML
    private void registroh() throws SQLException {
        nombre_hijo.requestFocus();

        boolean result = true;
        int identificacionh_registrada = 0;
        int identificacionm_registrada = 0;
        java.sql.ResultSet rs = cx.buscarmadres(Integer.parseInt(cedula_madre1.getText()));
        if (rs.next()) {
            java.sql.ResultSet rx = cx.buscarhijos(Integer.parseInt(identificacion_hijo.getText()));
            if (!rx.next()) {
                cx.registrarhijos(nombre_hijo.getText(), Integer.parseInt(identificacion_hijo.getText()), grado.getSelectionModel().getSelectedItem(), Integer.parseInt(cedula_madre1.getText()));
                clear_hijo();
            } else {
                JOptionPane.showMessageDialog(null, "Hijo ya existente...");
                clear_hijo();
                consultas_madre.setText("");
                consultas_hijo.setText("");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Madre no existente...");
            consultas_madre.setText("");
            consultas_hijo.setText("");
            clear_hijo();
        }
    }

    @FXML
    public void listarm() { //Metodo para listar madres

        taconsulta.setText(cx.mostrarmadres());
        clear_hijo();
        clear_madre();
        consultas_hijo.setText("");
    }

    @FXML
    public void listarh() { //Metodo para listar madres

        taconsulta.setText(cx.mostrahijos());
        clear_hijo();
        clear_madre();
        consultas_madre.setText("");
    }

    @FXML
    public void consultam() throws SQLException {
        String v="";
         int madre=0;
        java.sql.ResultSet rs = cx.buscarhijos(Integer.parseInt(tfcedulab.getText()));
        if(rs.next()){
            System.out.println("prueba");
            String j=(String.valueOf(rs.getString(4)));
             System.out.println(j);
            madre=Integer.parseInt(j);
            System.out.println(madre+1);
               taconsulta.setText(prueba(madre));
               clear_hijo();
               clear_madre();
        }else{ 
        }taconsulta.setText(prueba(madre));
               clear_hijo();
               clear_madre();
    }
public String prueba(int id) throws SQLException{
    String v="";
    java.sql.ResultSet rs = cx.buscarmadres(id);
    if(rs.next()){
         v=v+(rs.getString(1))+"\n";
                v=v+(String.valueOf(rs.getString(2)))+"\n";
               v=v+(rs.getString(3))+"\n";
                v=v+(rs.getString(4))+"\n";
                return v;
    }
    
    return v="Error";
}
    @FXML
    public void consultah() {
        clear_hijo();
        clear_madre();
        taconsulta.setText(cx.mostrarhijos((Integer.parseInt(tfcedulab.getText()))));
    }
public String prueba2(int id){
    return "a";
}
    public void consulta3() {

        String salida = "Listado de madres segun la letra: \n\n";;
        for (int ei = 1; ei <= tvm; ei++) {
            if (tfcedulab.getText().toUpperCase().charAt(0) == vm[ei].getNombre().charAt(0)) {
                salida = salida + vm[ei].getIdent() + ", " + vm[ei].getNombre() + "\n";

            }

            taconsulta.setText(salida);

        }

        tfcedulab.clear();
    }

    public void switchgrados() {
        int grado1 = grado.getSelectionModel().getSelectedItem();
        switch (grado1) {
            case 1:
                gradop++;
                break;
            case 2:
                grado2++;
                break;
            case 3:
                grado3++;
                break;
            case 4:
                grado4++;
                break;
            case 5:
                grado5++;
                break;
            case 6:
                grado6++;
                break;
            case 7:
                grado7++;
                break;
            case 8:
                grado8++;
                break;
            case 9:
                grado9++;
                break;
            case 10:
                grado10++;
                break;
            case 11:
                grado11++;
                break;

        }
    }

    public void consulta4() {
        int ei = 1;
        int sw = 0;
        String sCadena = vm[ei].getNombre();
        String sSubCadena = sCadena.substring(1);

    }

    public void clear_hijo() {

        identificacion_hijo.clear();
        nombre_hijo.clear();
        cedula_madre1.clear();
        lista_grados.clear();

    }

    public void clear_madre() {

        cedula_madre.clear();
        nombre_madre.clear();
        profesion.clear();
        direccion.clear();

    }

    public void alert() {

        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setHeaderText(null);
        alert.setTitle("Error");
        alert.setContentText("No se han ingresado datos");
        alert.showAndWait();

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cx = new Conexion();
        lista_grados = FXCollections.observableArrayList();
        lista_grados.addAll(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11);
        grado.getItems().addAll(lista_grados);

    }

    @FXML
    public void opconsulta1() {
        opc = 1;
        camposv();
        lbconsulta.setText("Ingrese identificacion del joven");
        tfcedulab.requestFocus();
    }

    @FXML
    public void opconsulta2() {
        opc = 2;
        camposv();
        lbconsulta.setText("Ingrese identificacion de la madre");
        tfcedulab.requestFocus();
    }

    public void opconsulta3() {
        opc = 3;
        camposv();
        lbconsulta.setText("Ingrese la letra para buscar a las madres");
        tfcedulab.requestFocus();
    }

    public void opconsulta4() {
        opc = 4;
        camposv();
        lbconsulta.setText("ingrese el grado donde quiere ver la cantidad de estudiantes");
        tfcedulab.requestFocus();
    }

    public void mostrargrados() {

        switch (Integer.parseInt(tfcedulab.getText())) {
            case 1:

                taconsulta.setText("La cantidad de niños son " + gradop);
                break;
            case 2:
                taconsulta.setText("La cantidad de niños son " + grado2);
                break;
            case 3:
                taconsulta.setText("La cantidad de niños son " + grado3);
                break;
            case 4:
                taconsulta.setText("La cantidad de niños son " + grado4);
                break;
            case 5:
                taconsulta.setText("La cantidad de niños son " + grado5);
                break;
            case 6:
                taconsulta.setText("La cantidad de niños son " + grado6);
                break;
            case 7:
                taconsulta.setText("La cantidad de niños son " + grado7);
                break;
            case 8:
                taconsulta.setText("La cantidad de niños son " + grado8);
                break;
            case 9:
                taconsulta.setText("La cantidad de niños son " + grado9);
                break;
            case 10:
                taconsulta.setText("La cantidad de niños son " + grado10);
                break;
            case 11:
                taconsulta.setText("La cantidad de niños son " + grado11);
                break;
        }

    }

    @FXML
    public void ejecutar() throws SQLException {
        switch (opc) {
            case 1:
                consultam();
                camposinv();
                cedula_madre.requestFocus();
                break;
            case 2:
                consultah();
                camposinv();
                cedula_madre.requestFocus();
                break;
            case 3:
                consulta3();
                camposinv();
                cedula_madre.requestFocus();
            case 4:
                mostrargrados();
                camposinv();
                cedula_madre.requestFocus();
        }

    }

    public void camposv() {
        lbconsulta.setVisible(true);
        tfcedulab.setVisible(true);
        btejecutar.setVisible(true);
    }

    public void camposinv() {
        tfcedulab.clear();
        lbconsulta.setVisible(false);
        tfcedulab.setVisible(false);
        btejecutar.setVisible(false);
    }
}

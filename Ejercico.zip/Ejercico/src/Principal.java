
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {

        Universidad universidad = new Universidad("---Universidad Simon Bolivar---");
        universidad.setDepartamentos(new Departamento("Ing. de Sistemas"));
        universidad.setDepartamentos(new Departamento("Ing. Electronica"));
        universidad.setDepartamentos(new Departamento("Ing. Civil"));

        boolean salir = false;
        int opcion;
        String datosMenu;

        while (salir != true) {
            datosMenu = "===SISTEMA UNIVERSITARIO===\n" + universidad.getNombre() + "\n"
                    + "1. Matricular Estudiante\n"
                    + "2. Asignar profesor a departamento\n"
                    + "3. Crear curso en el sistema\n"
                    + "4. Asignar alumnos a un curso\n"
                    + "5. Listar los datos de un curso\n"
                    + "6. Liatar cursos de un estudiante\n"
                    + "7. Salir\n"
                    + "\nIngresar opcion:\n";
            opcion = Integer.valueOf(JOptionPane.showInputDialog(datosMenu));
            switch (opcion) {
                case 1:
                    String nom;
                    String id;
                    String sem;

                    id = JOptionPane.showInputDialog("Ingrese el codigo del estudiante a matricular");
                    nom = JOptionPane.showInputDialog("Ingrese el nombre del estudiante a matricular");
                    sem = JOptionPane.showInputDialog("Ingrese el semestre del estudiante a matricular");
                    Estudiante e = new Estudiante(id, nom, sem);
                    nom = JOptionPane.showInputDialog(universidad.mostrarDepartamentos());
                    Departamento d = universidad.buscarDepartamento(nom);
                    if (d == null) {
                        JOptionPane.showMessageDialog(null, "Departamento no exite");
                        break;
                    }

                    universidad.matriuculaEstudiante(e, d);
                    JOptionPane.showMessageDialog(null, "El estudiante se matriculo");

                    break;
                case 2:
                    String nDep;
                    String nomProf;
                    String idProf;
                    String Cat;
                    nDep = JOptionPane.showInputDialog(universidad.mostrarDepartamentos() + "\nIngrese departamento de profesor a asignar:\n");
                    Departamento dep = universidad.buscarDepartamento(nDep);
                    if (dep == null) {
                        JOptionPane.showMessageDialog(null, "Departamento no exite");
                        break;
                    }

                    nomProf = JOptionPane.showInputDialog("Ingrese el nombre del profesro a asignar");
                    idProf = JOptionPane.showInputDialog("Ingrese el codigo del profesor a asignar");
                    Cat = JOptionPane.showInputDialog("Ingrese la categoria en la que va a trabajar");
                    Profesor profe = new Profesor(nomProf, idProf, Cat);
                    profe.setDepartamento(dep);
                    dep.setProfesor(profe);
                    JOptionPane.showMessageDialog(null, "El Profesor se a asignado con exito al " + dep.toString());
                    break;
                case 3:
                    String nDepa;
                    String codCurso;
                    String nombreCurso;
                    nDepa = JOptionPane.showInputDialog(universidad.mostrarDepartamentos() + "\nIngrese departamento pata nuevo curso a crear:\n");
                    Departamento depa = universidad.buscarDepartamento(nDepa);
                    if (depa == null) {
                        JOptionPane.showMessageDialog(null, "Departamento no exite");
                        break;
                    }
                    codCurso = JOptionPane.showInputDialog("\nIngrese codigo de curso a crear:\n");
                    Curso newCurso = depa.buscarCurso(codCurso);
                    if (newCurso != null) {
                        JOptionPane.showMessageDialog(null, "El codigo ingresado ya existe");
                        break;
                    }

                    nombreCurso = JOptionPane.showInputDialog("\nIngrese nombre del curso a crear:\n");
                    Curso nCurso = new Curso(nombreCurso, codCurso);

                    depa.setCurso(nCurso);
                    nCurso.setDepartamento(depa);
                    JOptionPane.showMessageDialog(null, "El nuevo curso " + nCurso.getNombre() + " se a creado con exito en el " + depa.toString());

                    break;
                case 4:
                    break;
                case 5:
                    break;
                case 6:
                    break;
                case 7:
                    salir = true;
                    break;

            }
        }

    }

}

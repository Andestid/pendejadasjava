
public class Persona {
    
    String id;
    String nom;

    public Persona(String id, String nom) {
        this.id = id;
        this.nom = nom;
    }

    public void setId(String id){
        this.id = id;
    }
    
    public void setNom(String nom){
        this.nom = nom;
    }

    public String getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }
    

   
    
    
    
    
    
}


import java.util.ArrayList;

public class Estudiante extends Persona {

    String sem;

    public Estudiante(String id, String nom, String sem) {

        super(id, nom);
        this.sem = sem;

    }
    ArrayList<Curso> cursos = new ArrayList<Curso>();
    Universidad universidad;
    Departamento departamento;
    
    

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

    public Universidad getUniversidad() {
        return universidad;
    }

    public void setUniversidad(Universidad universidad) {
        this.universidad = universidad;
    }

    public void setCursos(Curso curso) {
        cursos.add(curso);
    }

    public String getSem() {
        return sem;
    }

    public void setSem(String sem) {
        this.sem = sem;
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getNom() {
        return nom;
    }

}

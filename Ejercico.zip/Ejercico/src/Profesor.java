
import java.util.ArrayList;

public class Profesor extends Persona {

    String cat;

    public Profesor(String id, String nom, String cat) {

        super(id, nom);
        this.cat = cat;

    }

    public String getCat() {
        return cat;
    }

    public void setCat(String cat) {
        this.cat = cat;
    }

    public Profesor(String cat, Departamento departamento, String id, String nom) {
        super(id, nom);
        this.cat = cat;
        this.departamento = departamento;
    }
    
    
    

    @Override
    public String getId() {
        return id;
    }

    @Override
    public String getNom() {
        return nom;
    }

    Departamento departamento;
    ArrayList<Curso> cursos = new ArrayList<Curso>();

    public void setCursos(Curso curso) {
        cursos.add(curso);
    }

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

}

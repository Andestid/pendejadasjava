
import java.util.ArrayList;

public class Curso {

    String nombre;
    String codigoC;

    public Curso(String nombre, String codigoC) {
        this.nombre = nombre;
        this.codigoC = codigoC;
    }

    Profesor profesor;
    Departamento departamento;
    ArrayList<Estudiante> estudiantes = new ArrayList<Estudiante>();
    Universidad univesidad;

    public Departamento getDepartamento() {
        return departamento;
    }

    public void setDepartamento(Departamento departamento) {
        this.departamento = departamento;
    }

   

    public void setDEstudiantes(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCodigoC() {
        return codigoC;
    }

    public void setCodigoC(String codigoC) {
        this.codigoC = codigoC;
    }

    public Profesor getProfesor() {
        return profesor;
    }

    public void setProfesor(Profesor profesor) {
        this.profesor = profesor;
    }

    public Universidad getUnivesidad() {
        return univesidad;
    }

    public void setUnivesidad(Universidad univesidad) {
        this.univesidad = univesidad;
    }

    

}

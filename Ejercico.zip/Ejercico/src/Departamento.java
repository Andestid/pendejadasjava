
import java.util.ArrayList;
import java.util.Iterator;

public class Departamento {

    String nombre;

    public Departamento(String nombre) {
        this.nombre = nombre;
    }

    Universidad universidad;

    ArrayList<Profesor> profesores = new ArrayList<Profesor>();
    ArrayList<Estudiante> estudiantes = new ArrayList<Estudiante>();
    ArrayList<Curso> cursos = new ArrayList<Curso>();
    
     public Curso buscarCurso(String cod) {
        Curso c = null;
        Iterator<Curso> Iterator = cursos.iterator();
        while (Iterator.hasNext()) {
            c = Iterator.next();
            if (c.getNombre().equals(nombre)) {
                return c;
            }

        }
        c = null;
        return c;
    }
     
     

    @Override
    public String toString() {

        return "Departamento: " + nombre;
    }
    public void setCurso(Curso curso){
        cursos.add(curso);
    }

    public void setEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Universidad getUniversidad() {
        return universidad;
    }

    public void setUniversidad(Universidad universidad) {
        this.universidad = universidad;
    }

    public void setProfesor(Profesor profesor) {
        profesores.add(profesor);
    }

}


import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

public class Universidad {

    String nombre;

    ArrayList<Departamento> departamentos = new ArrayList<Departamento>();
    ArrayList<Estudiante> estudiantes = new ArrayList<Estudiante>();

    public Universidad(String nombre) {
        this.nombre = nombre;
    }

    public Departamento buscarDepartamento(String nombre) {
        Departamento d = null;
        Iterator<Departamento> Iterator = departamentos.iterator();
        while (Iterator.hasNext()) {
            d = Iterator.next();
            if (d.getNombre().equals(nombre)) {
                return d;
            }

        }
        d = null;
        return d;
    }
    
    public String mostrarDepartamentos(){
        String dato="";
        Iterator<Departamento> Iterator = departamentos.iterator();
        Departamento temp = null;
        while(Iterator.hasNext()){
            temp = Iterator.next();
            dato = dato + temp.toString()+"\n";
        }
        return dato;
    }

    public void matriuculaEstudiante(Estudiante estudiante, Departamento departamento) {
        estudiantes.add(estudiante);
        estudiante.setUniversidad(this);
        departamento.setEstudiante(estudiante);
        estudiante.setDepartamento(departamento);

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDepartamentos(Departamento departamento) {
        departamentos.add(departamento);
    }

    public void setEstudiantes(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

}

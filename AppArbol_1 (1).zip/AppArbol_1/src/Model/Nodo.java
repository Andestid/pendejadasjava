package Model;

public class Nodo {

    public Nodo LI;
    public int Dato;
    public int FB;
    public Nodo LD;

    public Nodo() {
        LI = null;
        LD = null;
        FB = 0;

    }

    public Nodo(int dato) {
        Dato = dato;
        LI = null;
        LD = null;
        FB = 0;

    }
}

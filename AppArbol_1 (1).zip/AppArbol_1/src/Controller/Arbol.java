package Controller;

import Model.Nodo;
import static java.lang.System.out;
import java.util.Random;
import javax.swing.JOptionPane;

public class Arbol {

    public Nodo Raiz;

    public Arbol() {
        Raiz = null;
    }
//-- Inorden (IRD)
    public String E;

    public void Inorden(Nodo R) {
        if (R != null) {
            Inorden(R.LI);
            System.out.println("Dato: " + R.Dato);
            Inorden(R.LD);
        }
    }

//-- Preorden (RID)
    public void Preorden(Nodo R) {
        if (R != null) {
            System.out.println("Dato: " + R.Dato);
            Preorden(R.LI);
            Preorden(R.LD);
        }
    }

//-- Posorden (IDR)
    public void Posorden(Nodo R) {
        if (R != null) {
            Posorden(R.LI);
            Posorden(R.LD);
            System.out.println("Dato: " + R.Dato);
        }
    }

    public void Insertar(Nodo R, int dato) {
        if (Raiz == null) {
            Raiz = new Nodo(dato);
            return;
        }
        if (dato < R.Dato) {
            if (R.LI == null) {
                R.LI = new Nodo(dato);
            } else {
                Insertar(R.LI, dato);
            }
        } else if (dato > R.Dato) {
            if (R.LD == null) {
                R.LD = new Nodo(dato);
            } else {
                Insertar(R.LD, dato);
            }
        } else {
            System.out.println("Error datos duplicado");
        }
    }

    public int Altura(Nodo R) {
        if (R == null) {
            return 0;
        } else {
            return 1 + (Math.max(Altura(R.LI), Altura(R.LD)));
        }
    }

    public int FB(Nodo R, int FB) {
        if (R != null) {
            FB = Altura(R.LI) - Altura(R.LD);
            if (FB < 2 && FB > -2) {
                System.out.println("Este arbol SI es AVL");

            } else {
                if (FB == -2) {
                    System.out.println("Este arbol NO es AVL");
                    System.out.println("Este arbol SI se puede convertir en AVL");
                } else {
                    if (FB == -3) {
                        System.out.println("Este arbol NO es AVL");
                        System.out.println("Este arbol  NO se puede convertir en AVL");
                    }
                }
            }
        }
        System.out.println("El factor de balance de este arbol es de: " + FB);
        return FB;

    }

}

package MODEL;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author lDomi
 */
public class Conexion {
    Connection con;
    Statement st;
    private static final String driver = "com.mysql.jdbc.Driver";
    private static final String user = "root";
    private static final String pass = "123";
    private static final String url = "jdbc:mysql://localhost:3306/ecocleandb?characterEncoding=latin1&useConfigs=maxPerformance";
    
    
//    public Connection Conexion(){
//        con = null;
//        try{
//            Class.forName(driver);
//            con = (Connection) DriverManager.getConnection(url, user, pass);
//        } catch (ClassNotFoundException | SQLException e) {
//            JOptionPane.showMessageDialog(null,e.getMessage());
//        }
//        return con;
//    }

    public Conexion() {
        try {
            Class.forName(driver);
            con = (Connection) DriverManager.getConnection(url, user, pass);
            st = con.createStatement();
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer conexión con la base de datos\n" + e, "Error de conexion", JOptionPane.ERROR_MESSAGE);
        }
    }

    public Connection getConnection() {
        return con;
    }

    public void Desconexion() {
        try {
            con.close();
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

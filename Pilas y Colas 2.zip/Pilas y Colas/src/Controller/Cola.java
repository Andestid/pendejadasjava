package Controller;

import Model.Nodo;
import javax.swing.JOptionPane;

public class Cola {

    private Nodo primero, ultimo;

    public Cola() {
        primero = null;
        ultimo = null;
    }

    public void encolar(int D) {
        Nodo x = new Nodo(D);
        if (ultimo != null) {
            ultimo.sig = x;
        } else {
            primero = x;
        }

        ultimo = x;
    }

    public Nodo desencolar() {
        Nodo x = primero;
        if (primero != null) {
            primero = primero.sig;
            x.sig = null;
            if (primero == null) {
                ultimo = null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error cola vacia");
        }
        return x;
    }

    public void imprimirC() {
        Nodo p = primero;
        String cad = "Elementos en la cola\n";
        while (p != null) {
            cad += p.Dato + "\n";
            p = p.sig;
        }
        JOptionPane.showMessageDialog(null, cad);
    }

    public void InsertarNcola() {
        int en = 0;
        int ei = 0;
        en = Integer.parseInt(JOptionPane.showInputDialog("Cuantos elementos desea insertar al inicio"));
        for (ei = 1; ei <= en; ei++) {
            Nodo x = new Nodo((int) (Math.random() * 100 + 1));
            x.sig = primero;
            primero = x;
        }

    }

    

}

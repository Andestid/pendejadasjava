package Controller;

import Model.Nodo;
import javax.swing.JOptionPane;

public class Pila {

    private Nodo tope;

    public Pila() {
        tope = null;

    }

    public boolean esvacia() {
        if (tope == null) {
            return true;
        }
        return false;
    }

    public void apilar(int D) {
        Nodo x = new Nodo(D);
        if (!esvacia()) {
            x.sig = tope;
        }
        tope = x;
    }

    public int desapilar() {
        int x = 0;
        if (esvacia()) {
            JOptionPane.showMessageDialog(null, "pila vacia");
        } else {
            x = tope.Dato;
            tope = tope.sig;
        }
        return x;
    }

    public void imprimirP() {
        Nodo p = tope;
        String cad = "Elementos Pila \n";
        while (p != null) {
            cad += p.Dato + "\n";
            p = p.sig;
        }

        JOptionPane.showMessageDialog(null, cad);
    }

    public void InsertarNpila() {
        int en = 0;
        int ei = 0;
        en = Integer.parseInt(JOptionPane.showInputDialog("Cuantos elementos desea insertar al inicio"));
        for (ei = 1; ei <= en; ei++) {
            Nodo x = new Nodo((int) (Math.random() * 100 + 1));
            x.sig = tope;
            tope = x;
        }
        

    }
}

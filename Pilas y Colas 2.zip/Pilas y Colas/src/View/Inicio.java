package View;

import Controller.Cola;
import Controller.Pila;
import Model.Nodo;
import javax.swing.JOptionPane;

public class Inicio extends javax.swing.JFrame {

    private Cola colas;
    private Pila pilas;
    private int dato;

    public Inicio() {
        initComponents();
        colas = new Cola();
        pilas = new Pila();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtdato = new javax.swing.JTextField();
        btnapilar = new javax.swing.JButton();
        btndesapilar = new javax.swing.JButton();
        btnencolar = new javax.swing.JButton();
        btndesencolar = new javax.swing.JButton();
        btnmostrarC = new javax.swing.JButton();
        btnmostrarP = new javax.swing.JButton();
        btnInsertarC = new javax.swing.JButton();
        BtninsertarP = new javax.swing.JButton();
        btnpac = new javax.swing.JButton();
        btncap = new javax.swing.JButton();
        btnsalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtdato.setBorder(javax.swing.BorderFactory.createTitledBorder("Dato"));

        btnapilar.setText("Apilar");
        btnapilar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnapilarActionPerformed(evt);
            }
        });

        btndesapilar.setText("Desapilar");
        btndesapilar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndesapilarActionPerformed(evt);
            }
        });

        btnencolar.setText("Encolar");
        btnencolar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnencolarActionPerformed(evt);
            }
        });

        btndesencolar.setText("Desencolar");
        btndesencolar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btndesencolarActionPerformed(evt);
            }
        });

        btnmostrarC.setText("Mostrar Cola");
        btnmostrarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmostrarCActionPerformed(evt);
            }
        });

        btnmostrarP.setText("Mostrar Pila");
        btnmostrarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnmostrarPActionPerformed(evt);
            }
        });

        btnInsertarC.setText("Insertar N colas");
        btnInsertarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsertarCActionPerformed(evt);
            }
        });

        BtninsertarP.setText("Insertar N pilas");
        BtninsertarP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtninsertarPActionPerformed(evt);
            }
        });

        btnpac.setText("Pila a Cola");
        btnpac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnpacActionPerformed(evt);
            }
        });

        btncap.setText("Cola a Pila");

        btnsalir.setText("Salir");
        btnsalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtdato, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnmostrarC)
                    .addComponent(btnmostrarP)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnapilar)
                        .addGap(77, 77, 77)
                        .addComponent(btnInsertarC))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btndesapilar)
                            .addComponent(btnencolar))
                        .addGap(55, 55, 55)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(BtninsertarP)
                            .addComponent(btnpac)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btndesencolar)
                        .addGap(44, 44, 44)
                        .addComponent(btncap)))
                .addContainerGap(125, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnsalir)
                .addGap(19, 19, 19))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtdato, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnapilar)
                    .addComponent(btnInsertarC))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndesapilar)
                    .addComponent(BtninsertarP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnencolar)
                    .addComponent(btnpac))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btndesencolar)
                    .addComponent(btncap))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnmostrarC)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnmostrarP)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnsalir)
                .addContainerGap(9, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnpacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnpacActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnpacActionPerformed

    private void btnsalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
        JOptionPane.showMessageDialog(null, "Gracias por utilizar el programa");
    }//GEN-LAST:event_btnsalirActionPerformed

    private void btnmostrarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmostrarCActionPerformed
        // TODO add your handling code here:
        colas.imprimirC();
    }//GEN-LAST:event_btnmostrarCActionPerformed

    private void btnmostrarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnmostrarPActionPerformed
        // TODO add your handling code here:
        pilas.imprimirP();
    }//GEN-LAST:event_btnmostrarPActionPerformed

    private void btnapilarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnapilarActionPerformed
        // TODO add your handling code here:
        dato = Integer.parseInt(txtdato.getText());
        pilas.apilar(dato);
        txtdato.setText("");
        JOptionPane.showMessageDialog(null, "Dato apilado correctamente");
    }//GEN-LAST:event_btnapilarActionPerformed

    private void btndesapilarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndesapilarActionPerformed
        // TODO add your handling code here:
        pilas.desapilar();
        txtdato.setText("");
        JOptionPane.showMessageDialog(null, "Dato desapilado de la pila");
        
    }//GEN-LAST:event_btndesapilarActionPerformed

    private void btnencolarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnencolarActionPerformed
        // TODO add your handling code here:
        dato = Integer.parseInt(txtdato.getText());
        colas.encolar(dato);
        txtdato.setText("");
        JOptionPane.showMessageDialog(null, "Dato encolado correctamente");
    }//GEN-LAST:event_btnencolarActionPerformed

    private void btndesencolarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btndesencolarActionPerformed
        // TODO add your handling code here:
        colas.desencolar();
        txtdato.setText("");
        JOptionPane.showMessageDialog(null, "Dato desencolado de la cola");
    }//GEN-LAST:event_btndesencolarActionPerformed

    private void btnInsertarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsertarCActionPerformed
        // TODO add your handling code here:
        colas.InsertarNcola();
        JOptionPane.showMessageDialog(null, "Elementos insertados a las colas");
        
    }//GEN-LAST:event_btnInsertarCActionPerformed

    private void BtninsertarPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtninsertarPActionPerformed
        // TODO add your handling code here:
        pilas.InsertarNpila();
        JOptionPane.showMessageDialog(null, "Elementos insertados a las pilas");
    }//GEN-LAST:event_BtninsertarPActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtninsertarP;
    private javax.swing.JButton btnInsertarC;
    private javax.swing.JButton btnapilar;
    private javax.swing.JButton btncap;
    private javax.swing.JButton btndesapilar;
    private javax.swing.JButton btndesencolar;
    private javax.swing.JButton btnencolar;
    private javax.swing.JButton btnmostrarC;
    private javax.swing.JButton btnmostrarP;
    private javax.swing.JButton btnpac;
    private javax.swing.JButton btnsalir;
    private javax.swing.JTextField txtdato;
    // End of variables declaration//GEN-END:variables
}

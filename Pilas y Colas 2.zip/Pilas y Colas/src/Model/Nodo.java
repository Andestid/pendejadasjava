package Model;

public class Nodo {

    public int Dato;
    public Nodo sig;

    public Nodo() {
        sig = null;
    }

    public Nodo(int D) {
        Dato = D;
        sig = null;
    }

}

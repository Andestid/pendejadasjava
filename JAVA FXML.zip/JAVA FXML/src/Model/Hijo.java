package Model;

import javax.swing.JOptionPane;

public class Hijo {

    private String nombre;
    private String sexo;
    private String fechan;
    private String id;
    private String idp;

    public Hijo(String nombre, String sexo, String fechan, String id, String idp) {
        this.nombre = nombre;
        this.sexo = sexo;
        this.fechan = fechan;
        this.id = id;
        this.idp = idp;

    }

    public String getNombre() {
        return nombre;
    }

    public String getSexo() {
        return sexo;
    }

    public String getFechan() {
        return fechan;
    }

    public String getId() {
        return id;
    }

    public String getIdp() {
        return idp;
    }

    public void mostrar() {
        String salida = "Identificación: " + getId()
                + "\nNombre: " + getNombre()
                + "\nSexo: " + getSexo()
                + "\nFecha de nacimiento: " + getFechan()
                + "\nIdentificacion del padre: " + getIdp();
        JOptionPane.showMessageDialog(null, salida, "Datos del hijo(a)", JOptionPane.INFORMATION_MESSAGE);
    }

}

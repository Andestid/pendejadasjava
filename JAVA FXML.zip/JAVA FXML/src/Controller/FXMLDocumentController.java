package Controller;

import Model.Hijo;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FXMLDocumentController implements Initializable {

    Hijo vh[] = new Hijo[10];

    int tvh = 0;
    int tvm = 0;
    int ej = 0;
    int ei = 0;
    boolean sw;

    @FXML
    private TextField cedula_madre;

    @FXML
    private TextField profesion;

    @FXML
    private TextField direccion;

    @FXML
    private TextField identificacion_hijo;

    @FXML
    private TextField nombre_hijo;

    @FXML
    private Button boton_registrar_hijo;

    @FXML
    private Button boton_listarh;

    @FXML
    private TextArea mensaje_hijo;

    @FXML
    private TextArea consultas_hijo;

    //Metodos para llamar
    @FXML
    private void registroh() {
        nombre_hijo.requestFocus();

        boolean result = true;
        int identificacionh_registrada = 0;
        int identificacionm_registrada = 0;

        if (identificacion_hijo.getText().isEmpty() || nombre_hijo.getText().isEmpty() || direccion.getText().isEmpty() || cedula_madre.getText().isEmpty() || profesion.getText().isEmpty()) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Faltan datos por ingresar!");
            alert.showAndWait();
            mensaje_hijo.clear();

        } else {

            for (ei = 1; ei <= tvm; ei++) {
                if (identificacion_hijo.getText().equals(vh[ei].getId())) {
                    identificacionh_registrada++;

                }
                if (identificacionh_registrada != 0) {

                    result = false;
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setTitle("Error");
                    alert.setContentText("¡Identificacion ya registrada!");
                    alert.showAndWait();
                    mensaje_hijo.clear();

                } else {
                    if (identificacion_hijo.getText().equals(vh[ei].getId())) {
                        identificacionm_registrada++;

                        if (tvh == 0) {
                            tvh++;
                            vh[tvh] = new Hijo(nombre_hijo.getText(), direccion.getText(), profesion.getText(), identificacion_hijo.getText(), cedula_madre.getText());
                            mensaje_hijo.setText("¡Hijo registrado\nexitosamente!");
                            clear_hijo();

                        }
                    }
                }

            }

        }

    }

    @FXML
    public void listarh() { //Metodo para listar madres

        if (tvh > 0) {
            consultas_hijo.clear();
            String salidah = "Lista de hijos registrados:\n\n";

            for (ei = 1; ei <= tvh; ei++) {

                salidah = salidah + ei + ". " + "Nombre: " + vh[ei].getNombre() + "\nID: " + vh[ei].getId() + "\nGrado: " + vh[ei].getSexo() + "\n\n";
            }

            consultas_hijo.setText(salidah);

        } else {
            String salidah = "No hay hijos registrados";
            consultas_hijo.setText(salidah);
        }

    }

    public void clear_hijo() {

        identificacion_hijo.clear();
        nombre_hijo.clear();
        cedula_madre.clear();
        direccion.clear();
        profesion.clear();

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }
}

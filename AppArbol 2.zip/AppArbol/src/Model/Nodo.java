package Model;

public class Nodo {

    public Nodo LI;
    public int Dato;
    public Nodo LD;

    public Nodo() {
        LI = null;
        LD = null;

    }

    public Nodo(int dato) {
        Dato = dato;
        LI = null;
        LD = null;

    }
}

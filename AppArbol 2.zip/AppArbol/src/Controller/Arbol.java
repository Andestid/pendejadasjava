package Controller;

import Model.Nodo;

public class Arbol {

    public Nodo Raiz;

    public Arbol() {
        Raiz = null;
    }
//-- Inorden (IRD)

    public void Inorden(Nodo R) {
        if (R != null) {
            Inorden(R.LI);
            System.out.println("Dato: " + R.Dato);
            Inorden(R.LD);
        }
    }

//-- Preorden (RID)
    public void Preorden(Nodo R) {
        if (R != null) {
            System.out.println("Dato: " + R.Dato);
            Preorden(R.LI);
            Preorden(R.LD);
        }
    }

//-- Posorden (IDR)
    public void Posorden(Nodo R) {
        if (R != null) {
            Posorden(R.LI);
            Posorden(R.LD);
            System.out.println("Dato: " + R.Dato);
        }
    }

    public void Insertar(Nodo R, int dato) {
        if (Raiz == null) {
            Raiz = new Nodo(dato);
            return;
        }
        if (dato < R.Dato) {
            if (R.LI == null) {
                R.LI = new Nodo(dato);
            } else {
                Insertar(R.LI, dato);
            }
        } else if (dato > R.Dato) {
            if (R.LD == null) {
                R.LD = new Nodo(dato);
            } else {
                Insertar(R.LD, dato);
            }
        } else {
            System.out.println("Error datos duplicado");
        }
    }

    public void Leonisa(Nodo R) {
        if (R != null) {
            Leonisa(R.LI);
            if (((R.LD != null) || (R.LI != null)) && R != Raiz) {

                System.out.println("Dato: " + R.Dato);
            }
            Leonisa(R.LD);
        }
    }

    public void Hojas(Nodo R) {
        if (R != null) {
            Hojas(R.LI);
            if ((R.LD == null) && (R.LI == null)) {

                System.out.println("Dato: " + R.Dato);
            }
            Hojas(R.LD);
        }
    }
    int c = 0;

    public void size(Nodo R) {
        if (R != null) {
            c = c + 1;
            size(R.LI);
            size(R.LD);
        }
    }
//--Inicio jframe

    public void ImprimirSize(Nodo R) {
        c = 0;
        size(R);
        System.out.println("No. de Nodos: " + c);
    }
//---- Contar retorne el valor

    public int Contar(Nodo R) {
        if (R != null) {
            return Contar(R.LI) + Contar(R.LD) + 1;//c=c+1
        } else {
            return 0;
        }
    }

    public void Promedio(Nodo R) {
        if (R != null) {
            Promedio(R.LI);
            c++;
            total = total + R.Dato;
            Promedio(R.LD);
        }
    }
    int D;
    int total;

    public void Imppromedio() {
        D = 0;
        total = 0;
        Promedio(Raiz);
        double promedio = total / D;
        javax.swing.JOptionPane.showMessageDialog(null, "Promedio de datos es: " + promedio);
    }

}

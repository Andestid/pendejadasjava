
package appcelebracion;

import javax.swing.JOptionPane;

public class Hijo extends Persona {

    //Atributos
    private int grado;
    private String cedmad;

    public Hijo(String ident, String nombre, int grado, String cedmad) {
       super(ident, nombre);
       this.grado=grado;
       this.cedmad=cedmad;
    }

    public String getCedmad() {
        return cedmad;
    }

    public int getGrado() {
        return grado;
    }

    @Override
    public void mostrar() {
        String salida = "Identificación: " + getIdent()
                + "\nNombre: " + getNombre()
                + "\nGrado: " + grado;
        JOptionPane.showMessageDialog(null, salida, "Datos del hijo(a)", JOptionPane.INFORMATION_MESSAGE);
    }

}

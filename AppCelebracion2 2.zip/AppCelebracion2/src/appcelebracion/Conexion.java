/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appcelebracion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Andrew
 */
public class Conexion {
     public static Connection getConnection()
    {
        Connection con = null;
        
        String driver = "com.mysql.cj.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/evento";
        String user = "root";
        String pass = "root";
        
        try
        {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, pass);
            
        }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        
        return con;
    }
      public boolean registrarMadre(String nombre, int cedula, String profesion, String direccion)
    {
        String sql = "INSERT INTO madres (nombre,cedula,profesion,direccion) VALUES (?,?,?,?)";
        
        Connection conectar;
        PreparedStatement pst;
        
        try
        {
            conectar = Conexion.getConnection();
            
            pst = conectar.prepareStatement(sql);
            
            pst.setString(1,nombre);
            pst.setInt(2, cedula);
            pst.setString(3, profesion);
            pst.setString(4, direccion);
            
            int result = pst.executeUpdate();
            
            if (result != 0)
            {
                JOptionPane.showMessageDialog(null,"Los datos se han guardado satisfactoriamente");
                
                return true;

            }
            else
            {
                JOptionPane.showMessageDialog(null,"Error en la transaccion");
                
                return false;
            }
            
        }
        catch(SQLException e)
        {            
            
            JOptionPane.showMessageDialog(null, e.getMessage());
            
            return false;
        }
        
    }
     public boolean registrarhijos(String nombre, int cedula,int grado, int cedulam)
    {
        String sql = "INSERT INTO hijos (nombre,cedula,grado,cedulam) VALUES (?,?,?,?)";
        
        Connection conectar;
        PreparedStatement pst;
        
        try
        {
            conectar = Conexion.getConnection();
            
            pst = conectar.prepareStatement(sql);
            
            pst.setString(1,nombre);
            pst.setInt(2, cedula);
            pst.setInt(3, grado);
            pst.setInt(4, cedulam);
            
            int result = pst.executeUpdate();
            
            if (result != 0)
            {
                JOptionPane.showMessageDialog(null,"Los datos se han guardado satisfactoriamente");
                
                return true;

            }
            else
            {
                JOptionPane.showMessageDialog(null,"Error en la transaccion");
                
                return false;
            }
            
        }
        catch(SQLException e)
        {            
            
            JOptionPane.showMessageDialog(null, e.getMessage());
            
            return false;
        }
        
    }
    public java.sql.ResultSet buscarmadres(int Id) throws SQLException
    {
        ResultSet rs = null;
        try
        {   
            String sql = "SELECT * FROM madres WHERE cedula="+String.valueOf(Id);
            Connection conectar;
            PreparedStatement pst;
            
            
            conectar = Conexion.getConnection();
            
            pst = conectar.prepareStatement(sql);
            
            rs = pst.executeQuery();
            
            if (rs.getRow() == 0)
            {             
                return rs;
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Error en la transaccion");
                
                return rs;
            }
            
        }
        catch(SQLException e)
        {            
            
            JOptionPane.showMessageDialog(null, e.getMessage());
            
           return rs;
        }
    }
     public java.sql.ResultSet buscarhijos(int Id) throws SQLException
    {
        ResultSet rs = null;
        try
        {   
            String sql = "SELECT * FROM hijos WHERE cedula="+String.valueOf(Id);
            Connection conectar;
            PreparedStatement pst;
            
            
            conectar = Conexion.getConnection();
            
            pst = conectar.prepareStatement(sql);
            
            rs = pst.executeQuery();
            
            if (rs.getRow() == 0)
            {             
                return rs;
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Error en la transaccion");
                
                return rs;
            }
            
        }
        catch(SQLException e)
        {            
            
            JOptionPane.showMessageDialog(null, e.getMessage());
            
           return rs;
        }
    }
    
    public String mostrarmadres()
    {
        String v="";
        String sql = "SELECT * FROM madres";        
        Connection cn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        try
        {
            cn = Conexion.getConnection();
            
            pst = cn.prepareStatement(sql);                        
            
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                String i = rs.getString("nombre");
                
                String n = rs.getString("cedula");
                
                String t = rs.getString("profesion");
                
               String d=rs.getString("direccion");
                v=v+"Nombre: "+i+" Cedula: "+n+" Profesion: "+t+" Direccion: "+d+"\n";
            }
            
           
        }
        catch(SQLException e)
        {
            
            JOptionPane.showMessageDialog(null,"Error al conectar");
            
        }
        finally
        {
            try
            {
                if (rs != null) rs.close();
                
                if (pst != null) pst.close();
                
                if (cn != null) cn.close();
            }
            catch(SQLException e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
        }
         return v;
    }
    public String mostrahijos()
    {
        String v="";
        String sql = "SELECT * FROM hijos";        
        Connection cn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        try
        {
            cn = Conexion.getConnection();
            
            pst = cn.prepareStatement(sql);                        
            
            rs = pst.executeQuery();
            
            while(rs.next())
            {
                String i = rs.getString("nombre");
                
                String n = rs.getString("cedula");
                
                String t = rs.getString("grado");
                
               String d=rs.getString("cedulam");
                v=v+"Nombre: "+i+" Identificacion: "+n+" Grado: "+t+" Cedula Madre: "+d+"\n";
            }
            
           
        }
        catch(SQLException e)
        {
            
            JOptionPane.showMessageDialog(null,"Error al conectar");
            
        }
        finally
        {
            try
            {
                if (rs != null) rs.close();
                
                if (pst != null) pst.close();
                
                if (cn != null) cn.close();
            }
            catch(SQLException e)
            {
                JOptionPane.showMessageDialog(null,e);
            }
        }
         return v;
    }
    
}

   


package appcelebracion;

public abstract class Persona {
    //Atributos

    private String ident;
    private String nombre;

    public Persona(String ident, String nombre) {
        this.ident = ident;
        this.nombre = nombre;
    }

    public abstract void mostrar();

    public String getIdent() {
        return ident;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

}

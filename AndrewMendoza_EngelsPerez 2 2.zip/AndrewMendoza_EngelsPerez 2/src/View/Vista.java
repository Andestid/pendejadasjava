package View;

import Model.Arbol;
import Controller.Controlador;

public class Vista extends javax.swing.JFrame {

    private Controlador arbolito;
    private Arbol dato;

    public Vista() {
        initComponents();
        arbolito = new Controlador();
        dato = new Arbol();
    }

    public void Nuevo() {
        txtnombre.setText("");
        txtedad.setText("");
        cmbsexo.setSelectedIndex(0);
        txtasig.setText("");
        txtp1.setText("");
        txtp2.setText("");
        txtexam.setText("");
        txtnombre.requestFocus();

    }

    public void Captura() {
        dato.nombre = txtnombre.getText();
        dato.edad = Integer.parseInt(txtedad.getText());
        dato.sexo = cmbsexo.getSelectedItem().toString();
        dato.asignatura = txtasig.getText();
        dato.p1 = Integer.parseInt(txtp1.getText());
        dato.p2 = Integer.parseInt(txtp2.getText());
        dato.examen = Integer.parseInt(txtexam.getText());
        dato.definitiva = ((dato.p1 * 0.3) + (dato.p2 * 0.3) + (dato.examen * 0.4) / 3);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtnombre = new javax.swing.JTextField();
        txtedad = new javax.swing.JTextField();
        txtp1 = new javax.swing.JTextField();
        txtp2 = new javax.swing.JTextField();
        txtexam = new javax.swing.JTextField();
        txtasig = new javax.swing.JTextField();
        btninsertar = new javax.swing.JButton();
        btnimprimir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txamostrar = new javax.swing.JTextArea();
        btnpunto3 = new javax.swing.JButton();
        cmbsexo = new javax.swing.JComboBox<>();
        btnsalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        txtnombre.setBorder(javax.swing.BorderFactory.createTitledBorder("Nombre"));

        txtedad.setBorder(javax.swing.BorderFactory.createTitledBorder("Edad"));

        txtp1.setBorder(javax.swing.BorderFactory.createTitledBorder("Nota 1"));

        txtp2.setBorder(javax.swing.BorderFactory.createTitledBorder("Nota 2"));

        txtexam.setBorder(javax.swing.BorderFactory.createTitledBorder("Examen"));

        txtasig.setBorder(javax.swing.BorderFactory.createTitledBorder("Asignatura"));

        btninsertar.setText("Insertar");
        btninsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btninsertarActionPerformed(evt);
            }
        });

        btnimprimir.setText("Imprimir");
        btnimprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnimprimirActionPerformed(evt);
            }
        });

        txamostrar.setColumns(20);
        txamostrar.setRows(5);
        jScrollPane1.setViewportView(txamostrar);

        btnpunto3.setText("Punto 3");

        cmbsexo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "--Seleccionar--", "M", "F" }));

        btnsalir.setText("Salir");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtasig, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbsexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(70, 70, 70)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 356, Short.MAX_VALUE)
                        .addGap(110, 110, 110))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtnombre, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE)
                            .addComponent(txtedad)
                            .addComponent(txtp1)
                            .addComponent(txtp2)
                            .addComponent(txtexam))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btnsalir)
                                .addContainerGap())
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(btninsertar)
                                .addGap(18, 18, 18)
                                .addComponent(btnimprimir)
                                .addGap(18, 18, 18)
                                .addComponent(btnpunto3)
                                .addGap(128, 128, 128))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtnombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtedad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cmbsexo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtasig, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtp1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtp2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtexam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 23, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnimprimir)
                            .addComponent(btninsertar)
                            .addComponent(btnpunto3))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnsalir)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btninsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btninsertarActionPerformed
        // TODO add your handling code here:
        Captura();
        arbolito.Insertar(arbolito.Raiz,dato);
        Nuevo();
        txamostrar.append("Dato: " + dato + " Insertado. \n");
        txtnombre.requestFocus();
    }//GEN-LAST:event_btninsertarActionPerformed

    private void btnimprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnimprimirActionPerformed
        // TODO add your handling code here:
        System.out.println("===============Inorden================");
        System.out.println("======================================");

        arbolito.Inorden(arbolito.Raiz);

        System.out.println("======================================");
    }//GEN-LAST:event_btnimprimirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vista().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnimprimir;
    private javax.swing.JButton btninsertar;
    private javax.swing.JButton btnpunto3;
    private javax.swing.JButton btnsalir;
    private javax.swing.JComboBox<String> cmbsexo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txamostrar;
    private javax.swing.JTextField txtasig;
    private javax.swing.JTextField txtedad;
    private javax.swing.JTextField txtexam;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtp1;
    private javax.swing.JTextField txtp2;
    // End of variables declaration//GEN-END:variables
}

package Controller;

import Model.Arbol;
import javax.swing.JOptionPane;

public class Controlador {

    public Arbol Raiz;

    public Controlador() {
        Raiz = null;
    }

    public void Inorden(Arbol R) {
        if (R != null) {
            Inorden(R.LI);
            System.out.println("Nombre: " + R.nombre);
            System.out.println("Curso: " + R.asignatura);
            System.out.println("Definitiva: " + R.definitiva);
            System.out.println("Edad: " + R.edad);
            Inorden(R.LD);
        }
    }

    public void Insertar(Arbol R, String nombre, String sexo, int edad, double p1, double p2, double examen, double definitiva, String curso) {
        if (Raiz == null) {
            Raiz = new Arbol(nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            return;
        }
        if (nombre.compareTo(R.nombre) < 0) {
            if (R.LI == null) {
                R.LI = new Arbol(nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            } else {
                Insertar(R.LI, nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            }
        } else if (nombre.compareTo(R.nombre) > 0) {
            if (R.LD == null) {
                R.LD = new Arbol(nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            } else {
                Insertar(R.LD, nombre, sexo, edad, p1, p2, examen, definitiva, curso);
            }
        } else {
            System.out.println("ERROR");
        }
        

    

    public void perdedores(Arbol R) {
        int o = 0;
        if (R != null) {
            if (R.sexo == "M") {
                if (R.definitiva < 3.0) {
                    o++;
                }
            }
            Inorden(R.LI);
            Inorden(R.LD);
        }
    }

    public void perdedores2(Arbol R) {

        o = 0;
        perdedores(R);
        System.out.println("Perdieron" + o + " Hombres");
    }
}
}
